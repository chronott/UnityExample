using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private CharacterController controller;
    [SerializeField] private Transform cam;
    [SerializeField] private float speed;

    private float angleX; //x�� ����
    private float angleY; //y�� ����

    private float horizontal;
    private float vertical;
    private float gravityY;
    private Vector3 moveDir;
    private float normalspeed;
   

    private void Awake()
    {
        Cursor.lockState = CursorLockMode.Locked;
        normalspeed = speed;
    }
    private void Update()
    {
        
        PlayerRotation();
        PlayerMove();
        PlayerShoot();

    }
    private void PlayerMove()
    {
        
        if (controller.isGrounded)
        {
            
            horizontal = Input.GetAxis("Horizontal"); // ���� ������ ����
            vertical = Input.GetAxis("Vertical"); // ���� ������ ����
            gravityY = 0;

            if (Input.GetKey(KeyCode.LeftShift))
            {
                if(speed < normalspeed * 2)
                {
                    speed *= 2;
                }
            }
         
            else if (Input.GetKey(KeyCode.X))
            {
                if (speed > normalspeed / 2)
                {
                    speed /= 2;
                }
            }
            else
            {
                speed = normalspeed;
            }


            if (Input.GetKey(KeyCode.Space)) // �����̽��ٸ� ������ ��
            {
                gravityY = 6f; // �ش� �ӵ���ŭ ���� �ö󰣴� = ����
            }

        }
        else
        {
            gravityY += Physics.gravity.y * Time.deltaTime; // �߷� ����.
        }

   
        

        moveDir = new Vector3(horizontal, 0, vertical);
        if (moveDir.magnitude > 1) // ��ȯ�� ���Ͱ��� 1���� Ŭ ���
        {
            moveDir.Normalize();
        }
        moveDir *= speed;
        moveDir.y = gravityY;


        controller.Move(Quaternion.Euler(0, angleY, 0) * moveDir * Time.deltaTime);
    }

    private void PlayerRotation()
    {
        angleX -= Input.GetAxis("Mouse Y");
        angleY += Input.GetAxis("Mouse X");

        cam.rotation = Quaternion.Euler(angleX, angleY, 0);
        cam.position = controller.transform.position;
    }

    private void PlayerShoot()
    {
        if (Input.GetMouseButton(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(new Vector2(Screen.width / 2, Screen.height / 2));

            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                if (hit.collider.gameObject.name == "Target")
                {
                    Destroy(hit.collider.gameObject);
                }
            }

        }
    }

}
